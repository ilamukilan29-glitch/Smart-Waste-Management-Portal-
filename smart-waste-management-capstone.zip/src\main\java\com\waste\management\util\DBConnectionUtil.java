package com.waste.management.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Database Connection Manager supporting HikariCP connection pooling
 * and graceful fallback to direct JDBC DriverManager.
 * Configured via classpath db.properties or environment variables.
 */
public class DBConnectionUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(DBConnectionUtil.class);

    private static HikariDataSource dataSource;
    private static Properties dbProps = new Properties();
    private static boolean initialized = false;

    private static String jdbcUrl;
    private static String jdbcUser;
    private static String jdbcPassword;
    private static String jdbcDriver;

    static {
        init();
    }

    public static synchronized void init() {
        if (initialized && dataSource != null && !dataSource.isClosed()) {
            return;
        }

        try {
            // Load properties from classpath
            try (InputStream in = DBConnectionUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
                if (in != null) {
                    dbProps.load(in);
                    LOGGER.info("Loaded db.properties from classpath");
                } else {
                    LOGGER.warn("db.properties not found on classpath, relying on environment or defaults");
                }
            } catch (Exception e) {
                LOGGER.warn("Could not load db.properties: {}", e.getMessage());
            }

            // Environment variables override properties file
            jdbcDriver = getEnvOrProp("DB_DRIVER", "db.driver", "com.mysql.cj.jdbc.Driver");
            String host = getEnvOrProp("DB_HOST", "db.host", "localhost");
            String port = getEnvOrProp("DB_PORT", "db.port", "3306");
            String name = getEnvOrProp("DB_NAME", "db.name", "waste_management_db");
            String defaultUrl = "jdbc:mysql://" + host + ":" + port + "/" + name + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";

            jdbcUrl = getEnvOrProp("DB_URL", "db.url", defaultUrl);
            jdbcUser = getEnvOrProp("DB_USER", "db.user", "root");
            jdbcPassword = getEnvOrProp("DB_PASSWORD", "db.password", "root");

            Class.forName(jdbcDriver);

            // Configure HikariCP connection pool
            HikariConfig config = new HikariConfig();
            config.setDriverClassName(jdbcDriver);
            config.setJdbcUrl(jdbcUrl);
            config.setUsername(jdbcUser);
            config.setPassword(jdbcPassword);
            config.setMaximumPoolSize(10);
            config.setMinimumIdle(2);
            config.setIdleTimeout(30000);
            config.setConnectionTimeout(10000);
            config.setLeakDetectionThreshold(60000);
            config.setPoolName("SmartWasteHikariPool");

            // Recommended MySQL optimizations
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            config.addDataSourceProperty("useServerPrepStmts", "true");

            try {
                dataSource = new HikariDataSource(config);
                LOGGER.info("HikariCP connection pool initialized successfully for URL: {}", jdbcUrl);
            } catch (Exception poolEx) {
                LOGGER.warn("HikariCP initialization failed, will fall back to direct DriverManager: {}", poolEx.getMessage());
                dataSource = null;
            }

            initialized = true;
        } catch (Exception e) {
            LOGGER.error("Failed to initialize database connectivity: {}", e.getMessage(), e);
        }
    }

    private static String getEnvOrProp(String envKey, String propKey, String defaultValue) {
        String val = System.getenv(envKey);
        if (val != null && !val.trim().isEmpty()) {
            return val.trim();
        }
        val = System.getProperty(envKey);
        if (val != null && !val.trim().isEmpty()) {
            return val.trim();
        }
        val = dbProps.getProperty(propKey);
        if (val != null && !val.trim().isEmpty()) {
            return val.trim();
        }
        return defaultValue;
    }

    /**
     * Obtains a JDBC Connection from the pool or via DriverManager.
     * Always close the connection in a try-with-resources block!
     */
    public static Connection getConnection() throws SQLException {
        if (!initialized) {
            init();
        }

        if (dataSource != null && !dataSource.isClosed()) {
            try {
                return dataSource.getConnection();
            } catch (SQLException e) {
                LOGGER.warn("HikariDataSource.getConnection() failed, attempting direct connection: {}", e.getMessage());
            }
        }

        // Direct DriverManager fallback
        return DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
    }

    /**
     * Closes the connection pool on application shutdown.
     */
    public static synchronized void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            LOGGER.info("Shutting down HikariCP connection pool");
            dataSource.close();
        }
    }

    public static String getJdbcUrl() {
        return jdbcUrl;
    }

    public static String getJdbcUser() {
        return jdbcUser;
    }
}
